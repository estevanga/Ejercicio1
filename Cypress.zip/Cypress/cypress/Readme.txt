Pasos para ejecutar la prueba Automatizada

1.Instalar NodeJS
  Verificar si NodeJS esta instalado node -v npm -v
  Descargar NodeJS
  Instalar NodeJS
  Verificar si se instalo correctamente

2 Instalar Cypress
  Crear una carpeta donde trabajar
  Abrir un cmd como adminsitrador y dirigirse a la carpeta
  Iniciar un proyecto de NodeJs npm init -y
  Instalar Cypress npm install cypress@10.3.0 --save-dev

3 Instalar Visual Studio code
  Descargar visual studio code
  Instalar visual studio code
  Abrir la carpeta donde instalamos Cypress
  Abrir la terminal y ejecutar Cypress npx cypress open

4 Configurar Cypress
  Elegir e2e testing
  Click continue
  Elegir el navegador y empezar el testing
  Seleccionar scafold 
  Ejecutar el test que deseamos para verificar que funcione
  Cerrar la interfaz de cypress
  Verificar que se crearon las carpetas en el proyecto

5. Configurar cypress.config.js la base de la url para el acceso 
6. configurar en package.json el ambiente de ejecución

5 Instalar xpath para cypress y colocar en e2e.js  la importación de xpath

6. Creación de proyecto e22
	Ejercicio1.cy.js

7. crear el paso de prueba 

8. Ejecutar el caso de prueba con npx cypress open

9. Seleccionar el browser para correr la prueba automatizada

10. Seleccionar el spec Ejercicion1.cy.js





