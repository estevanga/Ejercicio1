require('@cypress/xpath');

describe('Ejercicio 1', () => {
    it('Comparar', () => {
      cy.visit('https://opencart.abstracta.us/')
      //Add first itenm to cart     
      cy.screenshot('Inicio') 
      cy.get('a[href*="path=57"]').eq(2).click()
      cy.get('button[id="button-cart"]').click()
      // Add another item to cart
      cy.wait(1000)
      cy.screenshot('Primer Item') 
      cy.visit('https://opencart.abstracta.us/index.php?route=product/product&path=33&product_id=30')
      //Select red color
      cy.get("select").select(1).invoke("val").should("eq", "15")
      //
      cy.get('button[id="button-cart"]').click()
      
      cy.get('.btn-inverse').eq(0).should('be.visible').click({force: true})
      cy.screenshot('SegundoItem') 
      cy.wait(2000)  
      //Checkout
      cy.visit('https://opencart.abstracta.us/index.php?route=checkout/cart')
      cy.get('.btn-primary').eq(5).should('be.visible').click({force: true})
      //Guest checkout
      cy.get('[type="radio"]').check('guest')
      //Continue
      cy.get('.btn-primary').eq(0).click()
      //Fill input values
      cy.get('input[name=firstname').type('Esteban'); //
      cy.get('input[name=lastname').type('Guachamin'); //
      cy.get('input[id=input-payment-email').type('estevanga@icloud.com'); //
      cy.get('input[name=telephone').type('use0989442049'); //
      cy.get('input[name=company').type('Softka INC.'); //
      cy.get('input[name=address_1').type('Armenia'); //
      cy.get('input[name=address_2').type('Av. Amazonas y Pereira'); //
      cy.get('input[name=city').type('Quito'); //
      cy.get('input[name=postcode').type('EC170098'); //
      //Set Ecuador 62
      cy.get("select#input-payment-country").select(68).invoke("val").should("eq", "62")
      //Set Pichincha 997
      cy.get('select#input-payment-zone').select('997').should('have.value', '997')
      cy.screenshot('Formulario') 
     
      cy.get('.btn-primary').eq(2).click({force:true})
      cy.wait(2000)
      cy.get('.btn-primary').eq(4).click({force:true})
      cy.wait(1000)
        //Guest checkout
      cy.get('[type="radio"]').check('cod')
      //Accept Legcy
      cy.get('[type="checkbox"]').eq(1).check()
      //End Button
      cy.screenshot('GuessCheckout') 

      cy.get('.btn-primary').eq(5).click({force:true})
      cy.wait(1000)
      //Confirm button
      cy.xpath("//input[@id='button-confirm']").click({force:true})
      cy.wait(1000)
      
    })
  })